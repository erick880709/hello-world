

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

public class Roobot {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    //driver = new FirefoxDriver();
	  driver = new InternetExplorerDriver();
    baseUrl = "http://www.roboform.com/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testRoobot() throws Exception {
    driver.get(baseUrl + "/es/support/filling-test/custom-fields");
    new Select(driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr/td[2]/select"))).selectByVisibleText("Mrs");
    new Select(driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr/td[2]/select"))).selectByVisibleText("Mrs");
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[2]/td[2]/input[2]")).click();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[2]/td[2]/input[2]")).click();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[3]/td[2]/input")).clear();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[3]/td[2]/input")).sendKeys("HOLA");
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[3]/td[2]/input")).clear();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[3]/td[2]/input")).sendKeys("HOLA");
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[4]/td[2]/input")).clear();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[4]/td[2]/input")).sendKeys("PSL");
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[4]/td[2]/input")).clear();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[4]/td[2]/input")).sendKeys("PSL");
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[5]/td[2]/input")).clear();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[5]/td[2]/input")).sendKeys("MUCHO");
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[5]/td[2]/input")).clear();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[5]/td[2]/input")).sendKeys("MUCHO");
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[6]/td[2]/input")).clear();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[6]/td[2]/input")).sendKeys("GUSTO");
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[6]/td[2]/input")).clear();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[6]/td[2]/input")).sendKeys("GUSTO");
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[7]/td[2]/textarea")).clear();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[7]/td[2]/textarea")).sendKeys("ESTOY MUY CONTENTO DE SEGUIER EN EL PROCESO");
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[7]/td[2]/textarea")).clear();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[7]/td[2]/textarea")).sendKeys("ESTOY MUY CONTENTO DE SEGUIER EN EL PROCESO");
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[8]/td[2]/input")).click();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[8]/td[2]/input")).click();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[10]/td[2]/input")).click();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[10]/td[2]/input")).click();
    new Select(driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[11]/td[2]/select"))).selectByVisibleText("Casado");
    new Select(driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[11]/td[2]/select"))).selectByVisibleText("Casado");
    new Select(driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[14]/td[2]/select"))).selectByVisibleText("$15,000 - $19,999");
    new Select(driver.findElement(By.xpath("//div[@id='content']/div/div/form/table/tbody/tr[14]/td[2]/select"))).selectByVisibleText("$15,000 - $19,999");
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/p/input")).click();
    driver.findElement(By.xpath("//div[@id='content']/div/div/form/p/input")).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
