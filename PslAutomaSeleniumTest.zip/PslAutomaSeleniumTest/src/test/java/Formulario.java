

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

public class Formulario {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
   // driver = new FirefoxDriver();
	  driver = new InternetExplorerDriver();
    baseUrl = "http://www.roboform.com/es/support/filling-test/custom-fields";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testFormulario() throws Exception {
    driver.get(baseUrl);
    driver.findElement(By.xpath("//td[2]/input")).click();
    driver.findElement(By.xpath("//td[2]/input")).click();
    driver.findElement(By.xpath("//tr[3]/td[2]/input")).clear();
    driver.findElement(By.xpath("//tr[3]/td[2]/input")).sendKeys("hola estoy contento de seguir en el processo psl");
    driver.findElement(By.xpath("//tr[3]/td[2]/input")).clear();
    driver.findElement(By.xpath("//tr[3]/td[2]/input")).sendKeys("hola estoy contento de seguir en el processo psl");
    driver.findElement(By.xpath("//tr[4]/td[2]/input")).clear();
    driver.findElement(By.xpath("//tr[4]/td[2]/input")).sendKeys("tengo muchas expectativa");
    driver.findElement(By.xpath("//tr[4]/td[2]/input")).clear();
    driver.findElement(By.xpath("//tr[4]/td[2]/input")).sendKeys("tengo muchas expectativa");
    driver.findElement(By.xpath("//tr[5]/td[2]/input")).clear();
    driver.findElement(By.xpath("//tr[5]/td[2]/input")).sendKeys("de demostrar lo que se");
    driver.findElement(By.xpath("//tr[5]/td[2]/input")).clear();
    driver.findElement(By.xpath("//tr[5]/td[2]/input")).sendKeys("de demostrar lo que se");
    driver.findElement(By.xpath("//tr[6]/td[2]/input")).clear();
    driver.findElement(By.xpath("//tr[6]/td[2]/input")).sendKeys("y de aprender");
    driver.findElement(By.xpath("//tr[6]/td[2]/input")).clear();
    driver.findElement(By.xpath("//tr[6]/td[2]/input")).sendKeys("y de aprender");
    driver.findElement(By.xpath("//tr[8]/td[2]/input")).click();
    driver.findElement(By.xpath("//tr[8]/td[2]/input")).click();
    driver.findElement(By.xpath("//tr[10]/td[2]/input")).click();
    driver.findElement(By.xpath("//tr[10]/td[2]/input")).click();
    new Select(driver.findElement(By.xpath("//tr[11]/td[2]/select"))).selectByVisibleText("Casado");
    new Select(driver.findElement(By.xpath("//tr[11]/td[2]/select"))).selectByVisibleText("Casado");
    new Select(driver.findElement(By.xpath("//tr[14]/td[2]/select"))).selectByVisibleText("$20,000 - $39,999");
    new Select(driver.findElement(By.xpath("//tr[14]/td[2]/select"))).selectByVisibleText("$20,000 - $39,999");
    driver.findElement(By.xpath("//p/input")).click();
    driver.findElement(By.xpath("//p/input")).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
