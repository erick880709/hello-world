

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

public class BuscaCasaMedellin {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    //driver = new FirefoxDriver();
	  driver = new InternetExplorerDriver();
    baseUrl = "https://www.google.com/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testBuscaCasaMedellin() throws Exception {
    driver.get(baseUrl + "/search?q=fincaraiz&ie=utf-8&oe=utf-8&client=firefox-b-ab&gfe_rd=cr&ei=3Le8V-myCdO1mQG5m7H4Dg");
    driver.findElement(By.id("vs0p1c0")).click();
    driver.findElement(By.id("vs0p1c0")).click();
    driver.findElement(By.cssSelector("span.anchor")).click();
    driver.findElement(By.cssSelector("span.anchor")).click();
    driver.findElement(By.cssSelector("li.li.")).click();
    driver.findElement(By.cssSelector("li.li.")).click();
    driver.findElement(By.cssSelector("#divContainerTransaction > div.dropdown-check-list > span.anchor")).click();
    driver.findElement(By.cssSelector("#divContainerTransaction > div.dropdown-check-list > span.anchor")).click();
    driver.findElement(By.xpath("//li[@value='2']")).click();
    driver.findElement(By.xpath("//li[@value='2']")).click();
    driver.findElement(By.id("txtWord")).click();
    driver.findElement(By.id("txtWord")).click();
    driver.findElement(By.id("txtWord")).clear();
    driver.findElement(By.id("txtWord")).sendKeys("Antioqui");
    driver.findElement(By.id("txtWord")).clear();
    driver.findElement(By.id("txtWord")).sendKeys("Antioqui");
    driver.findElement(By.cssSelector("div.texto_selec_resaltado")).click();
    driver.findElement(By.cssSelector("div.texto_selec_resaltado")).click();
    driver.findElement(By.id("btnSearchAdvert")).click();
    driver.findElement(By.id("btnSearchAdvert")).click();
    driver.findElement(By.cssSelector("#divOfertType > div.dropdown-check-list > div.anchor")).click();
    driver.findElement(By.cssSelector("#divOfertType > div.dropdown-check-list > div.anchor")).click();
    driver.findElement(By.cssSelector("div.dropdown-check-list.visible > div.anchor")).click();
    driver.findElement(By.cssSelector("div.dropdown-check-list.visible > div.anchor")).click();
    driver.findElement(By.cssSelector("#divOfertType > div.dropdown-check-list > div.anchor")).click();
    driver.findElement(By.cssSelector("#divOfertType > div.dropdown-check-list > div.anchor")).click();
    driver.findElement(By.cssSelector("div.dropdown-check-list.visible > div.anchor")).click();
    driver.findElement(By.cssSelector("div.dropdown-check-list.visible > div.anchor")).click();
    driver.findElement(By.id("priceFromFilter")).clear();
    driver.findElement(By.id("priceFromFilter")).sendKeys("700.000");
    driver.findElement(By.id("priceFromFilter")).clear();
    driver.findElement(By.id("priceFromFilter")).sendKeys("700.000");
    driver.findElement(By.id("fl_search")).click();
    driver.findElement(By.id("fl_search")).click();
    driver.findElement(By.id("priceToFilter")).clear();
    driver.findElement(By.id("priceToFilter")).sendKeys("1.000.000");
    driver.findElement(By.id("priceToFilter")).clear();
    driver.findElement(By.id("priceToFilter")).sendKeys("1.000.000");
    driver.findElement(By.id("fl_search")).click();
    driver.findElement(By.id("fl_search")).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
